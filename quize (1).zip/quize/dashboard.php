<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'db.php';

// Session guard
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user'];
$user_query = mysqli_query($conn, "SELECT username FROM users WHERE id = '$user_id'");
$user_data = mysqli_fetch_assoc($user_query);
$username = htmlspecialchars($user_data['username']);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Online Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Quiz Maker</a>
        <div class="d-flex">
            <ul class="navbar-nav flex-row gap-3">
                <?php if(isset($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="create_quiz.php">Create Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="take_quiz.php">Take Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white text-decoration-underline" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="p-5 mb-4 bg-light rounded-3 border">
            <div class="container-fluid py-2">
                <h1 class="display-6 fw-bold">Hello, <?php echo $username; ?>!</h1>
                <p class="col-md-8 fs-5 text-muted">Welcome to your Quiz Maker dashboard. Choose an action below to get started.</p>
                <hr class="my-4">
                
                <div class="row g-4 mt-2">
                    <div class="col-sm-6">
                        <div class="card h-100 border">
                            <div class="card-body d-flex flex-column justify-content-between">
                                <div>
                                    <h5 class="card-title fw-bold text-primary">Create a Quiz</h5>
                                    <p class="card-text text-muted">Add a new quiz, write questions, and set the correct options.</p>
                                </div>
                                <a href="create_quiz.php" class="btn btn-outline-primary mt-3 w-100">Create Quiz</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-6">
                        <div class="card h-100 border">
                            <div class="card-body d-flex flex-column justify-content-between">
                                <div>
                                    <h5 class="card-title fw-bold text-success">Take a Quiz</h5>
                                    <p class="card-text text-muted">Browse available quizzes and test your knowledge.</p>
                                </div>
                                <a href="take_quiz.php" class="btn btn-outline-success mt-3 w-100">Take Quiz</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div> <!-- Closing Container -->

<footer class="text-center text-muted mt-5 py-3 border-top">
    <p>&copy; <?php echo date('Y'); ?> Online Quiz Maker. Created for Beginners.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>