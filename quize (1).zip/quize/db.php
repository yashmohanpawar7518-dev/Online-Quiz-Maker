<?php

$conn = mysqli_connect(
    "localhost",
    "root",
    "",
    "quiz_maker"
);

if(!$conn){
    die("Connection Failed");
}
?>