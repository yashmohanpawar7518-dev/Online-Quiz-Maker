<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'db.php';

// Session guard
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$success = '';
$error = '';

if (isset($_POST['create'])) {
    $title = mysqli_real_escape_string($conn, trim($_POST['title']));
    $question = mysqli_real_escape_string($conn, trim($_POST['question']));
    $op1 = mysqli_real_escape_string($conn, trim($_POST['op1']));
    $op2 = mysqli_real_escape_string($conn, trim($_POST['op2']));
    $op3 = mysqli_real_escape_string($conn, trim($_POST['op3']));
    $op4 = mysqli_real_escape_string($conn, trim($_POST['op4']));
    $correct = mysqli_real_escape_string($conn, trim($_POST['correct']));
    
    if (empty($title) || empty($question) || empty($op1) || empty($op2) || empty($op3) || empty($op4) || empty($correct)) {
        $error = "All fields are required to create a quiz.";
    } else {
        $created_by = $_SESSION['user'];
        $quiz_sql = "INSERT INTO quizzes(title, created_by) VALUES('$title', '$created_by')";
        
        if (mysqli_query($conn, $quiz_sql)) {
            $quiz_id = mysqli_insert_id($conn);
            $question_sql = "INSERT INTO questions (quiz_id, question, option1, option2, option3, option4, correct_answer) 
                             VALUES ('$quiz_id', '$question', '$op1', '$op2', '$op3', '$op4', '$correct')";
            
            if (mysqli_query($conn, $question_sql)) {
                $success = "Quiz created successfully! Go to 'Take Quiz' to play it.";
            } else {
                $error = "Failed to insert questions into database.";
            }
        } else {
            $error = "Failed to create quiz.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Create Quiz - Online Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Quiz Maker</a>
        <div class="d-flex">
            <ul class="navbar-nav flex-row gap-3">
                <?php if(isset($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="create_quiz.php">Create Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="take_quiz.php">Take Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white text-decoration-underline" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border mt-3">
            <div class="card-body p-4">
                <h2 class="card-title text-center mb-4">Create Quiz</h2>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success py-2"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger py-2"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="mb-3">
                        <label for="title" class="form-label">Quiz Title</label>
                        <input type="text" id="title" name="title" class="form-control" placeholder="Enter Quiz Title (e.g. Science Quiz)" required value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>">
                    </div>
                    
                    <div class="mb-3">
                        <label for="question" class="form-label">Question</label>
                        <textarea id="question" name="question" rows="3" class="form-control" placeholder="Enter your question here" required><?php echo isset($_POST['question']) ? htmlspecialchars($_POST['question']) : ''; ?></textarea>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="op1" class="form-label">Option 1</label>
                            <input type="text" id="op1" name="op1" class="form-control" placeholder="Option 1" required value="<?php echo isset($_POST['op1']) ? htmlspecialchars($_POST['op1']) : ''; ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="op2" class="form-label">Option 2</label>
                            <input type="text" id="op2" name="op2" class="form-control" placeholder="Option 2" required value="<?php echo isset($_POST['op2']) ? htmlspecialchars($_POST['op2']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="op3" class="form-label">Option 3</label>
                            <input type="text" id="op3" name="op3" class="form-control" placeholder="Option 3" required value="<?php echo isset($_POST['op3']) ? htmlspecialchars($_POST['op3']) : ''; ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="op4" class="form-label">Option 4</label>
                            <input type="text" id="op4" name="op4" class="form-control" placeholder="Option 4" required value="<?php echo isset($_POST['op4']) ? htmlspecialchars($_POST['op4']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="correct" class="form-label">Select Correct Option</label>
                        <select id="correct" name="correct" class="form-select" required>
                            <option value="">-- Choose Correct Option --</option>
                            <option value="option1" <?php echo (isset($_POST['correct']) && $_POST['correct'] == 'option1') ? 'selected' : ''; ?>>Option 1</option>
                            <option value="option2" <?php echo (isset($_POST['correct']) && $_POST['correct'] == 'option2') ? 'selected' : ''; ?>>Option 2</option>
                            <option value="option3" <?php echo (isset($_POST['correct']) && $_POST['correct'] == 'option3') ? 'selected' : ''; ?>>Option 3</option>
                            <option value="option4" <?php echo (isset($_POST['correct']) && $_POST['correct'] == 'option4') ? 'selected' : ''; ?>>Option 4</option>
                        </select>
                    </div>
                    
                    <div class="d-grid mt-4">
                        <button type="submit" name="create" class="btn btn-primary">Create Quiz</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</div> <!-- Closing Container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>