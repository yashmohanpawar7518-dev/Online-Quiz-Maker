<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'db.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Online Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Quiz Maker</a>
        <div class="d-flex">
            <ul class="navbar-nav flex-row gap-3">
                <?php if(isset($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="create_quiz.php">Create Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="take_quiz.php">Take Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white text-decoration-underline" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">

    <div class="text-center py-5">
        <h1 class="display-4 mb-3">Welcome to Online Quiz Maker</h1>
        <p class="lead mb-4 text-muted">Create your own custom quizzes or take quizzes created by other users!</p>
        
        <?php if(isset($_SESSION['user'])): ?>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <a href="dashboard.php" class="btn btn-primary btn-lg px-4 gap-3">Go to Dashboard</a>
            </div>
        <?php else: ?>
            <div class="d-grid gap-3 d-sm-flex justify-content-sm-center">
                <a href="login.php" class="btn btn-primary btn-lg px-4 gap-3">Login</a>
                <a href="register.php" class="btn btn-outline-secondary btn-lg px-4">Register</a>
            </div>
        <?php endif; ?>
    </div>

</div> 

<footer class="text-center text-muted mt-5 py-3 border-top">
    <p>&copy; <?php echo date('Y'); ?> Online Quiz Maker. Created for Beginners.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>