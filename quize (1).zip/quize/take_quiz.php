<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'db.php';

// Session guard
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

$result = mysqli_query($conn, "SELECT quizzes.*, users.username FROM quizzes LEFT JOIN users ON quizzes.created_by = users.id");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Take Quiz - Online Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Quiz Maker</a>
        <div class="d-flex">
            <ul class="navbar-nav flex-row gap-3">
                <?php if(isset($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="create_quiz.php">Create Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="take_quiz.php">Take Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white text-decoration-underline" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">

<div class="row justify-content-center">
    <div class="col-md-8">
        <h2 class="mb-4 text-center">Available Quizzes</h2>
        
        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="list-group shadow-sm">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="list-group-item list-group-item-action p-3 d-flex justify-content-between align-items-center border">
                        <div>
                            <h5 class="mb-1 fw-bold"><?php echo htmlspecialchars($row['title']); ?></h5>
                            <small class="text-muted">Created by: <?php echo htmlspecialchars($row['username'] ? $row['username'] : 'Anonymous'); ?></small>
                        </div>
                        <a href="result.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">Take Quiz</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center mt-3">
                <p class="mb-0">No quizzes are available right now. <a href="create_quiz.php" class="alert-link">Create one now!</a></p>
            </div>
        <?php endif; ?>
    </div>
</div>

</div> <!-- Closing Container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>