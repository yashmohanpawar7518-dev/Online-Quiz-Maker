<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once 'db.php';

// Session guard
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id'])) {
    header("Location: take_quiz.php");
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch quiz details
$quiz_res = mysqli_query($conn, "SELECT * FROM quizzes WHERE id = '$id'");
if (mysqli_num_rows($quiz_res) == 0) {
    echo "<div class='alert alert-danger'>Quiz not found.</div>";
    exit;
}
$quiz = mysqli_fetch_assoc($quiz_res);

// Fetch questions
$result = mysqli_query($conn, "SELECT * FROM questions WHERE quiz_id = '$id'");

$score = 0;
$total_questions = mysqli_num_rows($result);
$is_submitted = isset($_POST['submit']);
$submitted_answers = [];

// Helper function to check if a given option is the correct one
function isOptionCorrect($q, $opt_key) {
    $correct = trim($q['correct_answer']);
    
    // Check if correct answer matches key (e.g. 'option1')
    if (strcasecmp($correct, $opt_key) === 0) {
        return true;
    }
    // Check if correct answer matches option text
    if (strcasecmp($correct, trim($q[$opt_key])) === 0) {
        return true;
    }
    // Check if correct answer is numeric (1-4)
    if ($correct === '1' && $opt_key === 'option1') return true;
    if ($correct === '2' && $opt_key === 'option2') return true;
    if ($correct === '3' && $opt_key === 'option3') return true;
    if ($correct === '4' && $opt_key === 'option4') return true;
    
    return false;
}

if ($is_submitted) {
    mysqli_data_seek($result, 0);
    while ($q = mysqli_fetch_assoc($result)) {
        $q_id = $q['id'];
        $user_ans = isset($_POST['answer' . $q_id]) ? $_POST['answer' . $q_id] : '';
        $submitted_answers[$q_id] = $user_ans;
        
        // Check if user answer is correct
        $is_correct = false;
        if ($user_ans !== '') {
            // Check which option key matches the user's selected text
            $selected_key = '';
            if (strcasecmp(trim($user_ans), trim($q['option1'])) === 0) $selected_key = 'option1';
            elseif (strcasecmp(trim($user_ans), trim($q['option2'])) === 0) $selected_key = 'option2';
            elseif (strcasecmp(trim($user_ans), trim($q['option3'])) === 0) $selected_key = 'option3';
            elseif (strcasecmp(trim($user_ans), trim($q['option4'])) === 0) $selected_key = 'option4';
            
            if ($selected_key !== '') {
                $is_correct = isOptionCorrect($q, $selected_key);
            } else {
                // If it doesn't match any option text directly, try matching input value directly
                $is_correct = (strcasecmp(trim($user_ans), trim($q['correct_answer'])) === 0);
            }
        }
        
        if ($is_correct) {
            $score++;
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quiz Details - Online Quiz Maker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css?v=1.3">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Quiz Maker</a>
        <div class="d-flex">
            <ul class="navbar-nav flex-row gap-3">
                <?php if(isset($_SESSION['user'])): ?>
                    <li class="nav-item"><a class="nav-link text-white" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="create_quiz.php">Create Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="take_quiz.php">Take Quiz</a></li>
                    <li class="nav-item"><a class="nav-link text-white text-decoration-underline" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link text-white" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link text-white" href="register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-4">

<div class="row justify-content-center">
    <div class="col-md-9 col-lg-8">
        <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
            <h2>Taking Quiz: <span class="text-primary"><?php echo htmlspecialchars($quiz['title']); ?></span></h2>
            <a href="take_quiz.php" class="btn btn-outline-secondary btn-sm">Back to List</a>
        </div>
        
        <?php if ($is_submitted): ?>
            <div class="card border-primary mb-4 shadow-sm">
                <div class="card-body text-center">
                    <h3 class="card-title text-primary fw-bold">Quiz Submitted!</h3>
                    <h4 class="mt-2">Your Score: <span class="badge bg-primary fs-5"><?php echo $score; ?> / <?php echo $total_questions; ?></span></h4>
                    <p class="text-muted mt-2">See below for the correct answers and your selected choices.</p>
                </div>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <?php 
            mysqli_data_seek($result, 0);
            $q_num = 1;
            while ($q = mysqli_fetch_assoc($result)): 
                $q_id = $q['id'];
                $user_ans = isset($submitted_answers[$q_id]) ? $submitted_answers[$q_id] : '';
            ?>
                <div class="card mb-4 border shadow-sm">
                    <div class="card-header bg-light py-3">
                        <h5 class="mb-0 fw-bold">Question <?php echo $q_num++; ?>: <?php echo htmlspecialchars($q['question']); ?></h5>
                    </div>
                    <div class="card-body">
                        <?php 
                        $options = [
                            'option1' => $q['option1'],
                            'option2' => $q['option2'],
                            'option3' => $q['option3'],
                            'option4' => $q['option4']
                        ];
                        $user_selected_correct = false;
                        foreach ($options as $key => $val) {
                            if ($user_ans !== '' && strcasecmp(trim($user_ans), trim($val)) === 0) {
                                if (isOptionCorrect($q, $key)) {
                                    $user_selected_correct = true;
                                }
                            }
                        }
                        
                        foreach ($options as $key => $val):
                            $is_correct = false;
                            $is_selected = false;
                            $option_class = "";
                            $badge = "";
                            
                            // Check if option was selected by user
                            if ($user_ans !== '' && strcasecmp(trim($user_ans), trim($val)) === 0) {
                                $is_selected = true;
                            }
                            
                            if ($is_submitted) {
                                $is_correct = isOptionCorrect($q, $key);
                                if ($is_correct) {
                                    $option_class = "text-success fw-bold";
                                    if ($is_selected) {
                                        $badge = " <span class='badge bg-success ms-2'>✓ Correct choice</span>";
                                    } else {
                                        $badge = " <span class='badge bg-secondary ms-2'>Correct answer</span>";
                                    }
                                } elseif ($is_selected) {
                                    $option_class = "text-danger fw-bold";
                                    $badge = " <span class='badge bg-danger ms-2'>✗ Your choice (Incorrect)</span>";
                                }
                            }
                        ?>
                            <div class="form-check my-2 p-2 rounded <?php echo $is_submitted && $is_selected ? 'bg-light' : ''; ?>">
                                <input class="form-check-input ms-1" type="radio" 
                                       name="answer<?php echo $q_id; ?>" 
                                       id="opt_<?php echo $q_id . '_' . $key; ?>" 
                                       value="<?php echo htmlspecialchars($val); ?>" 
                                       <?php echo $is_selected ? 'checked' : ''; ?>
                                       <?php echo $is_submitted ? 'disabled' : ''; ?> required>
                                <label class="form-check-label ms-2 <?php echo $option_class; ?>" for="opt_<?php echo $q_id . '_' . $key; ?>">
                                    <?php echo htmlspecialchars($val); ?>
                                </label>
                                <?php echo $badge; ?>
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if ($is_submitted): ?>
                            <?php if ($user_selected_correct): ?>
                                <div class="alert alert-success py-2 mt-3 mb-0" style="font-size: 14px;">
                                    <strong>Correct!</strong> You got this question right.
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger py-2 mt-3 mb-0" style="font-size: 14px;">
                                    <strong>Incorrect!</strong> The correct answer is: <strong>
                                    <?php 
                                    $correct_text = "";
                                    foreach ($options as $key => $val) {
                                        if (isOptionCorrect($q, $key)) {
                                            $correct_text = $val;
                                            break;
                                        }
                                    }
                                    echo htmlspecialchars($correct_text);
                                    ?>
                                    </strong>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
            
            <?php if (!$is_submitted): ?>
                <div class="d-grid gap-2 mb-5">
                    <button type="submit" name="submit" class="btn btn-success btn-lg">Submit Answers</button>
                </div>
            <?php else: ?>
                <div class="d-grid gap-2 mb-5">
                    <a href="take_quiz.php" class="btn btn-primary btn-lg">Try Another Quiz</a>
                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

</div> <!-- Closing Container -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>